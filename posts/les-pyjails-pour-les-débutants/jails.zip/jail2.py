tips = 0

def hello():
	print("Pyjail niveau 2 :")
	print("Tu es encore bloqué dans mon environnement Python restreint sécurisé,\ntu ne peux t'y échaper qu'en appelant la fonction 'flag()'\nj'ai renforcé le système pour traiter l'entrée utilisateur.")
	print("Tu peux uniquement utiliser des commandes Python pour sortir d'ici.")
	print("Si tu as besoin d'un petit coup de main, la fonction 'tip()' te sera utile.")

def tip():
	global tips
	help_ = "Aide pour le challenge :"
	help_ = help_ + "\nQue fait le programme à l'entrée utilisateur ?"
	if tips >= 1:
		help_ = help_ + "\nQu'en est-il des variables ?"
	if tips >= 2:
		help_ = help_ + "\nPeut-on combiner ces éléments ?"
	if tips >= 3:
		help_ = help_ + "\nY'a t-il une fonction pour exécuter du code en Python ?"

	print(help_)
	tips = tips + 1

def flag():
	print("Tu es trop fort pour moi, voici ta récompense :\n")
	print(open("flag.txt","r").read())
	print("\nTu peux quitter ce programme et passer au suivant.")

def main():
	hello()
	while True:
		i = input("> ")

		while "flag()" in i:
			i = i.replace("flag()","")

		exec(i)

if __name__ == '__main__':
	main()