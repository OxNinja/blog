tips = 0

def hello():
	print("Pyjail niveau 3 :")
	print("Tu es encore bloqué dans mon environnement Python restreint sécurisé,\ntu ne peux t'y échaper qu'en appelant la fonction 'flag()' ou en trouvant le mot de passe\nj'ai renforcé le système pour traiter l'entrée utilisateur en ajoutant un filtre.")
	print("Tu peux uniquement utiliser des commandes Python pour sortir d'ici.")
	print("Si tu as besoin d'un petit coup de main, la fonction 'tip()' te sera utile.")

def tip():
	global tips
	help_ = "Aide pour le challenge :"
	help_ = help_ + "\nQuel est le nouveau filtre en place ?"
	if tips >= 1:
		help_ = help_ + "\nEst-il possible de trouver le mot de passe ?"
	if tips >= 2:
		help_ = help_ + "\nComment afficher les variables présentes ?"
	if tips >= 3:
		help_ = help_ + "\nVoir les fonctions pré-construites en Python (builtins)"

	print(help_)
	tips = tips + 1

def flag():
	print("Tu es trop fort pour moi, voici ta récompense :\n")
	print(open("flag.txt","r").read())
	print("\nTu peux quitter ce programme et passer au suivant.")

def main():
	filtered = ["flag()","\"","\'"]

	password = "sup3r_Passw0rd"

	hello()
	while True:
		print("Mot de passe ?")
		i = input("> ")

		if i == password:
			flag()
		else:
			for f in filtered:
				while f in i:
					i = i.replace(f,"")
			exec(i)

if __name__ == '__main__':
	main()