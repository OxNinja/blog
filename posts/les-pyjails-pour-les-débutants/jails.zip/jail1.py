def hello():
	print("Tu es bloqué dans mon environnement Python restreint sécurisé,\ntu ne peux t'y échaper qu'en appelant la fonction 'flag()'\nj'ai renforcé le système pour traiter l'entrée utilisateur.")
	print("Tu peux uniquement utiliser des commandes Python pour sortir d'ici.")

def flag():
	print("Tu es trop fort pour moi, voici ta récompense :\n")
	print(open("flag.txt","r").read())
	print("\nTu peux quitter ce programme et passer au suivant.")

def main():
	hello()
	while True:
		i = input("> ")
		i = i.replace("flag()","")
		exec(i)

if __name__ == '__main__':
	main()