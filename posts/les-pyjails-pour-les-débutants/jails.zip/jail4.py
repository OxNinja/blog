tips = 0

class SecretClass(object):
	"""docstring for SecretClass"""
	def __init__(self):
		print("Rien à voir ici, ouste !")

	def escapeMeNow():
		print("\nAppel de la fonction flag()...\n")
		flag()

def hello():
	print("Pyjail niveau 4 :")
	print("Tu es encore bloqué dans mon environnement Python restreint sécurisé,\ntu ne peux t'y échaper qu'en appelant la fonction 'flag()'\nil n'y a rien à trouver de plus, tu perds ton temps.")
	print("Tu peux uniquement utiliser des commandes Python pour sortir d'ici.")
	print("Si tu as besoin d'un petit coup de main, la fonction 'tip()' te sera utile.")

def tip():
	global tips
	help_ = "Aide pour le challenge :"
	help_ = help_ + "\nQu'est-ce qui a changé par rapport à la jail précédente ?"
	if tips >= 1:
		help_ = help_ + "\nN'y a-t-il pas d'autres choses à trouver que des variables locales ?"
	if tips >= 2:
		help_ = help_ + "\nVoir de nouveau les builtins Python"
	if tips >= 3:
		help_ = help_ + "\nQuelle classe que de sortir d'ici !"

	print(help_)
	tips = tips + 1

def flag():
	print("Tu es trop fort pour moi, voici ta récompense :\n")
	print(open("flag.txt","r").read())
	print("\nTu peux quitter ce programme et passer au suivant.")

def main():
	filtered = ["flag()","\"","\'"]

	hello()
	while True:
		i = input("> ")

		for f in filtered:
			while f in i:
				i = i.replace(f,"")
		exec(i)

if __name__ == '__main__':
	main()